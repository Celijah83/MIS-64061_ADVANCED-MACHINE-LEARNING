library(cloudml)

cloudml_train("R-script.R", master_type = "standard_gpu", config = "config.yml")


