library(tfruns)
library(cloudml)

cloudml_train("R-Script.R", master_type = "standard_gpu", config = "config.yml")


